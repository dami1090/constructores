#include <stdio.h>
#include <stdlib.h>


typedef struct
{
    int edad;
    char nombre[15];
    char color[15];
} eCaballo;

eCaballo* establo[3];

eCaballo* newCaballo();//Constructor por defecto
void mostrarCaballo(eCaballo*);
eCaballo* newCaballoParametros(int*, char*, char*);// constructor parametrizado

int main()
{

    eCaballo* establo[3];
    eCaballo* miCaballo;
    int edad;
    char nombre[15];
    char color[15];
    int i;

    for(i=0; i<3; i++)
    {
        miCaballo = newCaballoParametros( edad,  nombre,  color );
    }


        mostrarCaballo(miCaballo);
    return 0;
}
eCaballo* newCaballo()
{
    eCaballo* miCaballo;
    miCaballo = (eCaballo*) malloc(sizeof(eCaballo));
    return miCaballo;
}

eCaballo* newCaballoParametros(int* edad, char* color, char* nombre)
{
    int i;

    eCaballo* miCaballo;
    for (i=0;i<3;i++)
    {

    miCaballo = newCaballo();

    if(miCaballo!=NULL)
    {
        printf("ingrese nombre de caballo: \n");
        fflush(stdin);
        gets(nombre);
        printf("ingrese color para caballo: \n");
        fflush(stdin);
        gets(color);
        printf("ingrese edad: \n");
        scanf("%d",&edad);


        *(miCaballo+i)->color;
        (miCaballo+i)->edad;
        *(miCaballo+i)->nombre;

    }
        return miCaballo;
    }

}


void mostrarCaballo(eCaballo* caballo)
{
    int i;
    for (i=0;i<3;i++)
    {
    printf("%s--%d--%s\n", *(caballo+i)->nombre, (caballo+i)->edad, *(caballo+i)->color);
    }
}
